﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatternAssignment
{
    class Program
    {
        //--SAIF SAYYED
        static void Main(string[] args)
        {
            string answer = string.Empty;
            do
            {
                //--reading user input
                int Userinput = 0;
                Console.Write("Enter a number--->");
                Userinput = int.Parse(Console.ReadLine());

                //--if userinput is between 1 to 26
                Program _program = new Program();
                if (Userinput > 0 && Userinput <= 26)
                {
                    _program.CallFunction(Userinput, out answer);
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Enter number between 1 to 26 only");
                    Console.Write("Enter a number--->");
                    Userinput = int.Parse(Console.ReadLine());

                    _program.CallFunction(Userinput, out answer);
                }
            } while (answer.ToUpper() == "Y");
        }

        private void CallFunction(int Userinput, out string  answer)
        {
            //--checking ascii values and storing it in array 
            int AsciiCode = 122;
            int[] array = new int[Userinput];
            array[0] = AsciiCode;
            
            Program _program = new Program();
            for (int i = 1; i < Userinput; i++)
            {
                array[i] = AsciiCode - 1;
                AsciiCode--;
            }

            //--printing the value according to the user input
            for (int i = 1; i <= Userinput; i++)
            {                
                for (int j = 1; j <= Userinput - i; j++)
                {
                    Console.Write(" ");
                }
                for (int k = i; k >= 1; k--)
                {
                    Console.Write(_program.getAscii(array[k - 1]));
                }
                for (int l = 2; l <= i; l++)
                {
                    Console.Write(_program.getAscii(array[l - 1]));
                }
                Console.WriteLine();
            }

            for (int i = Userinput - 1; i >= 1; i--)
            {
                for (int j = 1; j <= Userinput - i; j++)
                {
                    Console.Write(" ");
                }
                for (int k = i; k >= 1; k--)
                {
                    Console.Write(_program.getAscii(array[k - 1]));
                }
                for (int l = 2; l <= i; l++)
                {                 
                    Console.Write(_program.getAscii(array[l - 1]));
                }
                Console.WriteLine();
            }            
            Console.Write("Do you want to continue?---->Y / N-->");
            answer = Console.ReadLine();
        }

        private string getAscii(int no)
        {
            char character = (char)no;
            string text = character.ToString();
            return text;
        }
    }
}
